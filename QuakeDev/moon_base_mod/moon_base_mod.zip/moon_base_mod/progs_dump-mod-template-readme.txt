This mod was created with the progs_dump mod devkit. For more info email dumptruck_ds at lango.lan.party@gmail.com

or  visit http://www.celephais.net/board/view_thread.php?id=61633

Credits

QuakeC
misc_model.qc, math.qc by Joshua Skelton
https://gist.github.com/joshuaskelly/15fe10fbaaa1bf87b341cba6e3ad2ebc

Trigger Spawned Monsters added via Preach’s excellent tutorial:
https://tomeofpreach.wordpress.com/2017/10/08/teleporting-monsters-flag/

custents by Carl Glave
http://www.quaketastic.com/files/tools/windows/quakec/custents.zip

various .qc from Hipnotic’s Quake Mission Pack Scourge of Armagon
Original Code written by Jim Dose and Mark Dochtermann
http://www.quaketastic.com/files/tools/windows/quakec/soa_all.zip

various .qc from Rogue’s Quake Mission Pack Dissolution of Eternity
Original Code written by Peter Mack et al.
http://www.quaketastic.com/files/tools/windows/quakec/doe_qc.zip

Preach’s clean Quake 1.06 source courtesy of Johnny Law
https://github.com/neogeographica/quakec/tree/1.06_Preach

various .qc from Rubicon Rumble Pack Devkit by ijed / Louis
http://www.quaketastic.com/files/single_player/mods/RRP_DEVKIT.zip

Arcane Dimensions code by Simon O’Callaghan
http://www.simonoc.com/pages/design/sp/ad.htm

Honey source by czg
https://www.quaddicted.com/reviews/honey.html

Zerstörer QuakeC Development Kit - Dave 'Ace_Dave' Weiden and Darin McNeil
https://www.quaddicted.com/reviews/zer.html

Rubicon 2 code copyright 2011 John Fitzgibbons.
https://www.quaddicted.com/reviews/rubicon2.html

deadstuff version 1.0 - Tony Collen
ftp://archives.gamers.org/pub/idgames2/quakec/level_enhancements/deadstuf.zip

Remake Quake code by Supa, ijed and (?)
https://icculus.org/projects/remakequake/

Slipgate by Michael Coburn
https://github.com/c0burn/Slipgate

Additional code and examples from iw, Qmaster, RennyC, Khreathor, Spike and c0burn.

Acknowledgements 

Thanks to the following people for their assistance and generosity. I could not have compiled this mod without their guidance either directly, through tutorials, mapping, code comments or forum posts: 

Qmaster, RennyC, c0burn, ydrol, Preach, Joshua Skelton, Spike, Khreathor, Shamblernaut, ericw, metlslime, necros, negke, Baker, sock, G1ftmacher, NewHouse, Johnny Law, iJed, ionous, McLogenog, Danz and many others on func_msgboard.

I also want to thank Pinchy, Mugwump, Len and PalmliX for their help with bug hunting. I apologize if I am forgetting anyone who assisted.

A special thank you to Ian “iw” Walshaw for his detailed comments, suggestions and for fixing a massive list of bugs for version 1.1.1 and above.

You can inquire about progs_dump on the Quake Mapping Discord: 

https://discordapp.com/invite/j5xh8QT

dumptruck’s Quake videos: 

https://www.youtube.com/c/dumptruckds

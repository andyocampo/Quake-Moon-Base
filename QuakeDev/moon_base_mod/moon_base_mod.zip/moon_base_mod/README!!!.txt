Moon Base Quake map

When you've loaded your modern Quake engine, type this in the console window:

GAME MOON_BASE_MOD

Then when it finishes loading, type in:

MAP MOONBASE